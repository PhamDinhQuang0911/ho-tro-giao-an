import { GoogleGenerativeAI } from "@google/generative-ai";
import mammoth from "mammoth";
import JSZip from "jszip";
import { GradeType, GeneratedNLSContent, NLSProcessingOptions } from "../types";

const LEVEL_MAPPING: Record<string, { ten: string, kyHieu: string, nhiemVu: string }> = {
  "Lớp 1": { ten: "Cơ bản 1", kyHieu: "CB1", nhiemVu: "Nhiệm vụ đơn giản, có hướng dẫn" },
  "Lớp 2": { ten: "Cơ bản 1", kyHieu: "CB1", nhiemVu: "Nhiệm vụ đơn giản, có hướng dẫn" },
  "Lớp 3": { ten: "Cơ bản 2", kyHieu: "CB2", nhiemVu: "Nhiệm vụ đơn giản, tự chủ hơn" },
  "Lớp 4": { ten: "Cơ bản 2", kyHieu: "CB2", nhiemVu: "Nhiệm vụ đơn giản, tự chủ hơn" },
  "Lớp 5": { ten: "Cơ bản 2", kyHieu: "CB2", nhiemVu: "Nhiệm vụ đơn giản, tự chủ hơn" },
  "Lớp 6": { ten: "Trung cấp 1", kyHieu: "TC1", nhiemVu: "Nhiệm vụ xác định rõ ràng, thường xuyên" },
  "Lớp 7": { ten: "Trung cấp 1", kyHieu: "TC1", nhiemVu: "Nhiệm vụ xác định rõ ràng, thường xuyên" },
  "Lớp 8": { ten: "Trung cấp 2", kyHieu: "TC2", nhiemVu: "Nhiệm vụ không thường xuyên, theo nhu cầu cá nhân" },
  "Lớp 9": { ten: "Trung cấp 2", kyHieu: "TC2", nhiemVu: "Nhiệm vụ không thường xuyên, theo nhu cầu cá nhân" },
  "Lớp 10": { ten: "Nâng cao 1", kyHieu: "NC1", nhiemVu: "Nhiệm vụ phức tạp, hướng dẫn người khác" },
  "Lớp 11": { ten: "Nâng cao 1", kyHieu: "NC1", nhiemVu: "Nhiệm vụ phức tạp, hướng dẫn người khác" },
  "Lớp 12": { ten: "Nâng cao 1", kyHieu: "NC1", nhiemVu: "Nhiệm vụ phức tạp, hướng dẫn người khác" },
};

const KHUNG_NLS_CONTEXT = `
KHUNG NĂNG LỰC SỐ (Tóm tắt cho AI):
1. Khai thác dữ liệu (I):
- 1.1. Tìm kiếm và lọc (TC1: Tìm theo quy trình; TC2: Tổ chức chiến lược tìm kiếm).
- 1.2. Đánh giá dữ liệu (TC1: So sánh độ tin cậy; TC2: Phân tích nguồn tin).
- 1.3. Quản lý dữ liệu (TC1: Lưu trữ có cấu trúc; TC2: Sắp xếp để dễ truy xuất).

2. Giao tiếp và hợp tác (II):
- 2.1. Tương tác (TC1: Tương tác thường xuyên; TC2: Chọn nhiều công cụ phù hợp bối cảnh như Zalo, Padlet, LMS).
- 2.2. Chia sẻ (TC1: Chọn công nghệ phù hợp; TC2: Vận dụng chia sẻ, trích dẫn nguồn).
- 2.3. Trách nhiệm công dân (TC1: Tham gia dịch vụ số; TC2: Đề xuất dịch vụ số).
- 2.4. Hợp tác (TC1: Chọn công cụ hợp tác; TC2: Đồng sáng tạo sản phẩm).
- 2.5. Netiquette (TC1: Ứng xử phù hợp; TC2: Điều chỉnh chiến lược giao tiếp).

3. Sáng tạo nội dung số (III):
- 3.1. Phát triển nội dung (TC1: Tạo định dạng cơ bản Word/PPT; TC2: Tạo đa định dạng Video/Infographic/Podcast).
- 3.2. Tích hợp nội dung (TC1: Sửa đổi cơ bản; TC2: Tích hợp, tạo cái mới độc đáo).
- 3.3. Bản quyền (TC1: Phân biệt giấy phép; TC2: Áp dụng quy định bản quyền).
- 3.4. Lập trình (TC1: Viết lệnh đơn giản; TC2: Hiểu nguyên lý, viết chuỗi lệnh).

4. An toàn (IV): Bảo vệ thiết bị, dữ liệu cá nhân, sức khỏe và môi trường.
5. Giải quyết vấn đề (V):
- 5.1. Vấn đề kỹ thuật (TC1: Xử lý lỗi cơ bản; TC2: Phân tích nguyên nhân lỗi).
- 5.2. Nhu cầu công nghệ (TC1: Chọn công cụ phù hợp; TC2: Tùy chỉnh môi trường số, chọn giải pháp tối ưu).
- 5.3. Sáng tạo công nghệ (TC1: Tạo sản phẩm mới; TC2: Đổi mới quy trình, giải quyết tình huống thực tế).
- 5.4. Lỗ hổng năng lực (TC1: Tìm cơ hội học tập; TC2: Lập kế hoạch tự học).

6. Trí tuệ nhân tạo (VI): Hiểu biết, sử dụng có đạo đức và đánh giá công cụ AI.
`;

export async function extractTextFromDocx(file: File): Promise<string> {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  return result.value;
}

export function createIntegrationTextPrompt(keHoachText: string, monHoc: string, khoiLop: string): string {
  const mucDoInfo = LEVEL_MAPPING[khoiLop];
  if (!mucDoInfo) throw new Error(`Chưa hỗ trợ ${khoiLop}`);

  return `Bạn là Chuyên gia Sư phạm số và Công nghệ giáo dục. Nhiệm vụ: Tích hợp Năng lực số (NLS) sâu và cụ thể vào giáo án ${monHoc} ${khoiLop}.

Cấp độ NLS áp dụng: ${mucDoInfo.ten} (${mucDoInfo.kyHieu}). Nhiệm vụ: ${mucDoInfo.nhiemVu}.

THAM CHIẾU KHUNG NLS:
${KHUNG_NLS_CONTEXT}

Dưới đây là nội dung giáo án gốc:
"""
${keHoachText.substring(0, 30000)} 
"""

### CHIẾN LƯỢC TÍCH HỢP (THEO MÔN HỌC):
1. **Toán/KHTN/Công nghệ:** 
   - Kiểm chứng: Dùng Casio/Excel/GeoGebra kiểm tra kết quả tính tay.
   - Mô phỏng: Dùng PhET/Desmos quan sát hiện tượng/đồ thị.
   - Mã NLS gợi ý: 5.2 (Chọn công cụ), 5.3 (Sáng tạo/Hiểu sâu), 1.2 (Đánh giá dữ liệu).
2. **Xã hội/Nghệ thuật (Âm nhạc, Mỹ thuật):**
   - Sáng tạo: Canva (Infographic), CapCut (Video), Podcast, MuseScore, các app vẽ số.
   - Chia sẻ: Padlet, Zalo, Google Drive.
   - Mã NLS gợi ý: 3.1 (Tạo nội dung), 2.2 (Chia sẻ), 2.4 (Hợp tác).
3. **Chung:**
   - Đánh giá: Kahoot, Quizizz, Google Forms.

### YÊU CẦU ĐẦU RA (ĐỊNH DẠNG TEXT THÔ BẮT BUỘC):
Dùng chính xác các thẻ phân cách sau:

===BAT_DAU_MUC_TIEU===
(Viết 3-4 gạch đầu dòng mục tiêu NLS. Cấu trúc: [Mã NLS]: [Hành động cụ thể]. Ví dụ: 5.2.TC2b: Sử dụng GeoGebra để...)
===KET_THUC_MUC_TIEU===

===BAT_DAU_HOC_LIEU===
(Liệt kê thiết bị/phần mềm. Ví dụ: Máy tính cầm tay, Điện thoại, App Desmos, Padlet...)
===KET_THUC_HOC_LIEU===

===BAT_DAU_HOAT_DONG===
(Chọn 2-3 hoạt động tiêu biểu nhất để chèn NLS)

ANCHOR: (Trích dẫn chính xác 1 câu ngắn trong giáo án gốc làm điểm neo)
CONTENT: (Mô tả chi tiết. Bắt đầu bằng **➤ Tích hợp NLS ([Mã]):**. Mô tả rõ: GV yêu cầu gì? HS dùng công cụ gì? Kết quả là gì?)
---PHAN_CACH_HOAT_DONG---
ANCHOR: (Điểm neo 2...)
CONTENT: (Nội dung 2...)
===KET_THUC_HOAT_DONG===

===BAT_DAU_PHU_LUC===
(Tạo Bảng tổng hợp mã năng lực. Trình bày dạng Markdown Table gồm 3 cột: Mã NLS | Yêu cầu cần đạt | Học sinh làm gì (Cụ thể).)
===KET_THUC_PHU_LUC===
`;
}

export async function generateCompetencyIntegration(prompt: string, apiKey: string): Promise<GeneratedNLSContent> {
  const genAI = new GoogleGenerativeAI(apiKey);
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    return parseStructuredResponse(text);
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw new Error(`Lỗi AI: ${error.message}`);
  }
}

function parseStructuredResponse(text: string): GeneratedNLSContent {
  const result: GeneratedNLSContent = {
    objectives_addition: "",
    materials_addition: "",
    activities_integration: [],
    appendix_table: ""
  };

  const objectivesMatch = text.match(/===BAT_DAU_MUC_TIEU===([\s\S]*?)===KET_THUC_MUC_TIEU===/);
  if (objectivesMatch) result.objectives_addition = objectivesMatch[1].trim();

  const materialsMatch = text.match(/===BAT_DAU_HOC_LIEU===([\s\S]*?)===KET_THUC_HOC_LIEU===/);
  if (materialsMatch) result.materials_addition = materialsMatch[1].trim();

  const appendixMatch = text.match(/===BAT_DAU_PHU_LUC===([\s\S]*?)===KET_THUC_PHU_LUC===/);
  if (appendixMatch) result.appendix_table = appendixMatch[1].trim();

  const activitiesBlockMatch = text.match(/===BAT_DAU_HOAT_DONG===([\s\S]*?)===KET_THUC_HOAT_DONG===/);
  if (activitiesBlockMatch) {
    const rawActivities = activitiesBlockMatch[1].split('---PHAN_CACH_HOAT_DONG---');
    rawActivities.forEach(block => {
      const anchorMatch = block.match(/ANCHOR:\s*([\s\S]*?)(?=CONTENT:|$)/);
      const contentMatch = block.match(/CONTENT:\s*([\s\S]*?)$/);
      if (anchorMatch && contentMatch) {
        result.activities_integration.push({
          anchor_text: anchorMatch[1].trim(),
          content: contentMatch[1].trim()
        });
      }
    });
  }

  return result;
}

export async function injectNLSIntoDocx(zip: JSZip, nlsContent: GeneratedNLSContent, log: (msg: string) => void): Promise<void> {
  const docXmlFile = zip.file("word/document.xml");
  if (!docXmlFile) throw new Error("File word/document.xml không tồn tại.");

  let docXmlStr = await docXmlFile.async("string");
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(docXmlStr, "application/xml");
  const w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

  const baseStyle = extractBaseStyles(xmlDoc);

  // 1. Insert Objectives
  if (nlsContent.objectives_addition) {
    const objectivesPara = findParagraphByText(xmlDoc, ["Về năng lực", "Năng lực:", "2. Năng lực"]);
    if (objectivesPara) {
      const style = getParaStyle(objectivesPara);
      const font = style.font || baseStyle.font;
      const size = style.size || baseStyle.size;
      
      const lines = nlsContent.objectives_addition.split('\n').reverse();
      lines.forEach(line => {
        if (line.trim()) {
          const newPara = createParagraphNode(xmlDoc, line.trim(), false, "000000", font, size);
          objectivesPara.parentNode?.insertBefore(newPara, objectivesPara.nextSibling);
        }
      });
    }
  }

  // 2. Insert Materials
  if (nlsContent.materials_addition) {
    const materialsPara = findParagraphByText(xmlDoc, ["Thiết bị dạy học", "Học liệu", "Chuẩn bị của giáo viên"]);
    if (materialsPara) {
      const style = getParaStyle(materialsPara);
      const font = style.font || baseStyle.font;
      const size = style.size || baseStyle.size;

      const lines = nlsContent.materials_addition.split('\n').reverse();
      lines.forEach((line, index) => {
        if (line.trim()) {
          const prefix = index === lines.length - 1 ? "Học liệu số: " : "";
          const newPara = createParagraphNode(xmlDoc, prefix + line.trim(), false, "000000", font, size);
          materialsPara.parentNode?.insertBefore(newPara, materialsPara.nextSibling);
        }
      });
    }
  }

  // 3. Insert Activities
  if (nlsContent.activities_integration.length > 0) {
    for (const item of nlsContent.activities_integration) {
      const anchorPara = findParagraphByFuzzyText(xmlDoc, item.anchor_text);
      if (anchorPara) {
        const style = getParaStyle(anchorPara);
        const font = style.font || baseStyle.font;
        const size = style.size || baseStyle.size;

        const newPara = createParagraphNode(xmlDoc, item.content, false, "107C10", font, size);
        anchorPara.parentNode?.insertBefore(newPara, anchorPara.nextSibling);
      }
    }
  }

  // 4. Append Appendix Table
  const body = xmlDoc.getElementsByTagNameNS(w, "body")[0];
  if (body) {
    const headerPara = createParagraphNode(xmlDoc, "PHỤ LỤC: BẢNG TỔNG HỢP MÃ NĂNG LỰC SỐ", true, "000000", baseStyle.font, baseStyle.size);
    body.appendChild(headerPara);
    const lines = nlsContent.appendix_table.split('\n');
    lines.forEach(line => {
      if (line.trim()) body.appendChild(createParagraphNode(xmlDoc, line, false, "000000", baseStyle.font, baseStyle.size));
    });
  }

  const serializer = new XMLSerializer();
  const newDocXmlStr = serializer.serializeToString(xmlDoc);
  zip.file("word/document.xml", newDocXmlStr);
}

function findParagraphByText(xmlDoc: Document, searchPhrases: string[]): Element | null {
  const paragraphs = xmlDoc.getElementsByTagName("w:p");
  for (let i = 0; i < paragraphs.length; i++) {
    const textContent = paragraphs[i].textContent || "";
    for (const phrase of searchPhrases) {
      if (textContent.toLowerCase().includes(phrase.toLowerCase())) return paragraphs[i];
    }
  }
  return null;
}

function findParagraphByFuzzyText(xmlDoc: Document, anchor: string): Element | null {
  const paragraphs = xmlDoc.getElementsByTagName("w:p");
  const cleanAnchor = anchor.trim().toLowerCase().substring(0, 30);
  for (let i = 0; i < paragraphs.length; i++) {
    if ((paragraphs[i].textContent || "").trim().toLowerCase().includes(cleanAnchor)) return paragraphs[i];
  }
  return null;
}

function createParagraphNode(
  xmlDoc: Document, 
  text: string, 
  isBold: boolean = false, 
  colorHex: string = "000000",
  font?: string,
  size?: string
): Element {
  const w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
  const p = xmlDoc.createElementNS(w, "w:p");
  const r = xmlDoc.createElementNS(w, "w:r");
  const rPr = xmlDoc.createElementNS(w, "w:rPr");
  
  if (isBold) rPr.appendChild(xmlDoc.createElementNS(w, "w:b"));
  
  const color = xmlDoc.createElementNS(w, "w:color");
  color.setAttribute("w:val", colorHex);
  rPr.appendChild(color);

  if (font) {
    const rFonts = xmlDoc.createElementNS(w, "w:rFonts");
    rFonts.setAttribute("w:ascii", font);
    rFonts.setAttribute("w:hAnsi", font);
    rFonts.setAttribute("w:cs", font);
    rPr.appendChild(rFonts);
  }

  if (size) {
    const sz = xmlDoc.createElementNS(w, "w:sz");
    sz.setAttribute("w:val", size);
    rPr.appendChild(sz);
    
    const szCs = xmlDoc.createElementNS(w, "w:szCs");
    szCs.setAttribute("w:val", size);
    rPr.appendChild(szCs);
  }

  const t = xmlDoc.createElementNS(w, "w:t");
  t.setAttribute("xml:space", "preserve");
  t.textContent = text;
  r.appendChild(rPr);
  r.appendChild(t);
  p.appendChild(r);
  return p;
}

export function getParaStyle(para: Element | null): { font?: string, size?: string } {
  if (!para) return {};
  const runs = para.getElementsByTagName("w:r");
  for (let i = 0; i < runs.length; i++) {
    const rPr = runs[i].getElementsByTagName("w:rPr")[0];
    if (rPr) {
      const rFonts = rPr.getElementsByTagName("w:rFonts")[0];
      const sz = rPr.getElementsByTagName("w:sz")[0];
      const font = rFonts?.getAttribute("w:ascii");
      const size = sz?.getAttribute("w:val");
      if (font || size) return { font: font || undefined, size: size || undefined };
    }
  }
  const pPr = para.getElementsByTagName("w:pPr")[0];
  if (pPr) {
    const rPr = pPr.getElementsByTagName("w:rPr")[0];
    if (rPr) {
      const rFonts = rPr.getElementsByTagName("w:rFonts")[0];
      const sz = rPr.getElementsByTagName("w:sz")[0];
      const font = rFonts?.getAttribute("w:ascii");
      const size = sz?.getAttribute("w:val");
      if (font || size) return { font: font || undefined, size: size || undefined };
    }
  }
  return {};
}

export function extractBaseStyles(xmlDoc: Document): { font?: string, size?: string } {
  const paragraphs = xmlDoc.getElementsByTagName("w:p");
  for (let i = 0; i < Math.min(paragraphs.length, 50); i++) {
    const style = getParaStyle(paragraphs[i]);
    if (style.font && style.size) return style;
  }
  return { font: "Times New Roman", size: "26" };
}
