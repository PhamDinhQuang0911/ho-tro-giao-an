import JSZip from 'jszip';
import { format, addDays, startOfWeek } from 'date-fns';
import { GeneratedNLSContent, NLSProcessingOptions, ReflectionSettings } from '../types';
import { extractTextFromDocx, createIntegrationTextPrompt, generateCompetencyIntegration, injectNLSIntoDocx, extractBaseStyles } from './nls-utils';

export interface ScheduleItem {
  id: string;
  dayOfWeek: number; // 0 (Sun) to 6 (Sat)
  subject: string;
  className: string;
  period?: string; // Optional period/session identifier (e.g., "Tiết 1")
}

export interface HeaderFooterSettings {
  topLeft: string;
  topRight: string;
  bottomLeft: string;
  bottomRight: string;
}

export interface ProcessingOptions {
  weekNumber: string;
  periodNumber: string;
  prepDate: Date;
  schedule: ScheduleItem[];
  subject: string;
  lessonCount: number;
  classOffsets: Record<string, number>; // Map of className to startSessionIndex
  headerFooter?: HeaderFooterSettings;
  nlsOptions?: NlsOptions;
  reflection?: ReflectionSettings;
  weekOffset?: number; // 1 or 2
}

interface NlsOptions extends NLSProcessingOptions {
  apiKey: string;
}

/**
 * Generates the XML for the lesson plan header table.
 */
function generateHeaderXml(options: ProcessingOptions, style: { font?: string, size?: string }) {
  const { weekNumber, periodNumber, prepDate, schedule, subject, lessonCount, classOffsets, weekOffset } = options;
  const formattedPrepDate = format(prepDate, 'dd/MM/yyyy');

  const fontXml = style.font ? `<w:rFonts w:ascii="${style.font}" w:hAnsi="${style.font}" w:cs="${style.font}"/>` : '';
  const sizeXml = style.size ? `<w:sz w:val="${style.size}"/><w:szCs w:val="${style.size}"/>` : '<w:sz w:val="28"/><w:szCs w:val="28"/>';

  // Calculate teaching dates
  const weekOffsetVal = weekOffset || 1;
  const startOfTargetWeek = addDays(startOfWeek(prepDate, { weekStartsOn: 1 }), 7 * weekOffsetVal);
  const weeksToCalculate = 4; // Look ahead 4 weeks to handle delays
  
  const allAvailableSessionsByClass: Record<string, any[]> = {};

  const getSessionsForWeek = (weekStart: Date, weekOffsetIdx: number) => {
    const currentWeekNum = (parseInt(weekNumber) || 0) + weekOffsetIdx;
    return schedule
      .filter(s => s.subject.toLowerCase() === subject.toLowerCase())
      .sort((a, b) => {
        const dayA = a.dayOfWeek === 0 ? 7 : a.dayOfWeek;
        const dayB = b.dayOfWeek === 0 ? 7 : b.dayOfWeek;
        if (dayA !== dayB) return dayA - dayB;
        return (a.period || '').localeCompare(b.period || '');
      })
      .map(s => {
        const date = addDays(weekStart, s.dayOfWeek === 0 ? 6 : s.dayOfWeek - 1);
        return { 
          className: s.className, 
          date: format(date, 'dd/MM/yyyy'), 
          rawDate: date,
          period: s.period,
          weekNum: currentWeekNum.toString()
        };
      });
  };

  const classes = Array.from(new Set(schedule
    .filter(s => s.subject.toLowerCase() === subject.toLowerCase())
    .map(s => s.className)
  ));

  classes.forEach(className => {
    let classSessions: any[] = [];
    for (let i = 0; i < weeksToCalculate; i++) {
      const weekStart = addDays(startOfTargetWeek, i * 7);
      const sessions = getSessionsForWeek(weekStart, i);
      classSessions = [...classSessions, ...sessions.filter(s => s.className === className)];
    }
    allAvailableSessionsByClass[className] = classSessions;
  });

  let earliestTeachingDate: Date | null = null;

  const teachingSessions = classes.map(className => {
    const allAvailableSessions = allAvailableSessionsByClass[className] || [];
    
    // Use per-class offset or default to 1
    const startSessionIndex = classOffsets[className] || 1;
    const startIndex = startSessionIndex - 1;
    const selectedSessions = allAvailableSessions.slice(startIndex, startIndex + lessonCount);

    // Track earliest date
    selectedSessions.forEach(s => {
      if (!earliestTeachingDate || s.rawDate < earliestTeachingDate) {
        earliestTeachingDate = s.rawDate;
      }
    });

    // Calculate weeks involved for this class
    const weeksInvolved = new Set<string>();
    selectedSessions.forEach(s => {
      weeksInvolved.add(s.weekNum);
    });

    const dateToPeriods: Record<string, string[]> = {};
    selectedSessions.forEach(s => {
      if (!dateToPeriods[s.date]) dateToPeriods[s.date] = [];
      if (s.period) dateToPeriods[s.date].push(s.period);
    });

    const displayDates = Object.entries(dateToPeriods).map(([date, periods]) => {
      if (periods.length > 1) {
        // Multiple sessions of THIS lesson plan on this day
        return `${date} (${periods.join(', ')})`;
      }
      // Only one session of this lesson plan on this day, just show the date
      return date;
    });

    return { className, dates: displayDates.join(', ') || 'N/A', weeksInvolved };
  });

  // Calculate global week display
  const allWeeks = new Set<string>();
  teachingSessions.forEach(s => s.weeksInvolved.forEach(w => allWeeks.add(w)));
  const sortedWeeks = Array.from(allWeeks).sort((a, b) => (parseInt(a) || 0) - (parseInt(b) || 0));
  const weekDisplay = sortedWeeks.join(', ');

  // Calculate global period display
  const startPeriod = parseInt(periodNumber) || 0;
  const periodDisplay = lessonCount > 1 
    ? `${startPeriod} - ${startPeriod + lessonCount - 1}`
    : periodNumber;

  // Word XML for the header matching the user's image
  let xml = `
    <w:p>
      <w:pPr>
        <w:pBdr>
          <w:top w:val="single" w:sz="4" w:space="1" w:color="auto"/>
        </w:pBdr>
      </w:pPr>
    </w:p>
    <w:p>
      <w:pPr>
        <w:tabs>
          <w:tab w:val="right" w:pos="9000"/>
        </w:tabs>
        <w:jc w:val="both"/>
      </w:pPr>
      <w:r>
        <w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr>
        <w:t>Tuần: ${weekDisplay}</w:t>
      </w:r>
      <w:r>
        <w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr>
        <w:tab/>
        <w:t>Tiết PPCT: ${periodDisplay}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr>
        <w:t>Ngày soạn: ${formattedPrepDate}</w:t>
      </w:r>
    </w:p>
    <w:tbl>
      <w:tblPr>
        <w:tblStyle w:val="TableGrid"/>
        <w:tblW w:w="0" w:type="auto"/>
        <w:jc w:val="left"/>
        <w:tblBorders>
          <w:top w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          <w:left w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          <w:bottom w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          <w:right w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          <w:insideH w:val="single" w:sz="4" w:space="0" w:color="auto"/>
          <w:insideV w:val="single" w:sz="4" w:space="0" w:color="auto"/>
        </w:tblBorders>
      </w:tblPr>
      <w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="1500" w:type="dxa"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="left"/></w:pPr><w:r><w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr><w:t>Lớp</w:t></w:r></w:p>
        </w:tc>
        ${teachingSessions.map(s => `
        <w:tc>
          <w:tcPr><w:tcW w:w="1500" w:type="dxa"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr>${fontXml}${sizeXml}</w:rPr><w:t>${s.className}</w:t></w:r></w:p>
        </w:tc>
        `).join('')}
      </w:tr>
      <w:tr>
        <w:tc>
          <w:tcPr><w:tcW w:w="1500" w:type="dxa"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="left"/></w:pPr><w:r><w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr><w:t>Lịch dạy dự kiến</w:t></w:r></w:p>
        </w:tc>
        ${teachingSessions.map(s => `
        <w:tc>
          <w:tcPr><w:tcW w:w="1500" w:type="dxa"/></w:tcPr>
          <w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr>${fontXml}${sizeXml}</w:rPr><w:t>${s.dates}</w:t></w:r></w:p>
        </w:tc>
        `).join('')}
      </w:tr>
    </w:tbl>
    <w:p><w:r><w:br w:type="textWrapping"/></w:r></w:p>
  `;
  return { xml, earliestTeachingDate };
}

function generateReflectionXml(settings: ReflectionSettings, style: { font?: string, size?: string }, earliestTeachingDate: Date | null) {
  if (!settings.enabled) return '';

  const fontXml = style.font ? `<w:rFonts w:ascii="${style.font}" w:hAnsi="${style.font}" w:cs="${style.font}"/>` : '';
  const sizeXml = style.size ? `<w:sz w:val="${style.size}"/><w:szCs w:val="${style.size}"/>` : '<w:sz w:val="28"/><w:szCs w:val="28"/>';
  const smallSizeXml = style.size ? `<w:sz w:val="${Math.max(20, parseInt(style.size) - 4)}"/><w:szCs w:val="${Math.max(20, parseInt(style.size) - 4)}"/>` : '<w:sz w:val="24"/><w:szCs w:val="24"/>';

  let signingDateStr = `ngày ...... tháng ...... năm ${settings.year}`;
  
  if (settings.autoSigningDate && earliestTeachingDate) {
    // Calculate Saturday of the week BEFORE the earliest teaching date
    // 1. Find the start of the week of the earliest teaching date (Monday)
    const startOfTeachingWeek = startOfWeek(earliestTeachingDate, { weekStartsOn: 1 });
    // 2. Go back 2 days from Monday to get Saturday
    const signingDate = addDays(startOfTeachingWeek, -2);
    signingDateStr = `ngày ${format(signingDate, 'dd')} tháng ${format(signingDate, 'MM')} năm ${format(signingDate, 'yyyy')}`;
  }

  let linesXml = '';
  // Use a shorter dot line to avoid wrapping on standard margins
  const dotLine = "..........................................................................................";
  for (let i = 0; i < settings.contentLines; i++) {
    linesXml += `
      <w:p>
        <w:pPr><w:jc w:val="both"/></w:pPr>
        <w:r>${fontXml}${sizeXml}<w:t>${dotLine}</w:t></w:r>
      </w:p>`;
  }

  return `
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr></w:p>
    <w:p>
      <w:pPr><w:jc w:val="left"/></w:pPr>
      <w:r>
        <w:rPr><w:b/>${fontXml}${sizeXml}</w:rPr>
        <w:t>${settings.title.toUpperCase()}</w:t>
      </w:r>
    </w:p>
    ${linesXml}
    <w:p>
      <w:pPr>
        <w:tabs><w:tab w:val="right" w:pos="9000"/></w:tabs>
        <w:jc w:val="both"/>
      </w:pPr>
      <w:r>
        <w:tab/>
        <w:rPr><w:i/>${fontXml}${smallSizeXml}</w:rPr>
        <w:t>Ký duyệt, ${signingDateStr}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:tabs><w:tab w:val="right" w:pos="9000"/></w:tabs>
        <w:jc w:val="both"/>
      </w:pPr>
      <w:r>
        <w:tab/>
        <w:rPr><w:b/>${fontXml}${smallSizeXml}</w:rPr>
        <w:t>${settings.approverTitle}</w:t>
      </w:r>
    </w:p>
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr></w:p>
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr></w:p>
    <w:p><w:pPr><w:jc w:val="both"/></w:pPr></w:p>
    <w:p>
      <w:pPr>
        <w:tabs><w:tab w:val="right" w:pos="9000"/></w:tabs>
        <w:jc w:val="both"/>
      </w:pPr>
      <w:r>
        <w:tab/>
        <w:rPr><w:b/>${fontXml}${smallSizeXml}</w:rPr>
        <w:t>${settings.approverName}</w:t>
      </w:r>
    </w:p>
  `;
}

function generateHeaderFooterXmls(settings: HeaderFooterSettings) {
  const headerXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <w:hdr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
      <w:p>
        <w:pPr>
          <w:tabs><w:tab w:val="right" w:pos="9000"/></w:tabs>
          <w:jc w:val="both"/>
        </w:pPr>
        <w:r><w:rPr><w:sz w:val="20"/></w:rPr><w:t>${settings.topLeft}</w:t></w:r>
        <w:r><w:tab/><w:rPr><w:sz w:val="20"/></w:rPr><w:t>${settings.topRight}</w:t></w:r>
      </w:p>
    </w:hdr>`;

  const footerXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
      <w:p>
        <w:pPr>
          <w:tabs>
            <w:tab w:val="center" w:pos="4500"/>
            <w:tab w:val="right" w:pos="9000"/>
          </w:tabs>
          <w:jc w:val="both"/>
        </w:pPr>
        <w:r><w:rPr><w:sz w:val="20"/></w:rPr><w:t>${settings.bottomLeft}</w:t></w:r>
        <w:r><w:tab/><w:rPr><w:sz w:val="20"/></w:rPr><w:fldSimple w:instr=" PAGE "/></w:r>
        <w:r><w:tab/><w:rPr><w:sz w:val="20"/></w:rPr><w:t>${settings.bottomRight}</w:t></w:r>
      </w:p>
    </w:ftr>`;

  return { headerXml, footerXml };
}

export async function processWordFile(file: File, options: ProcessingOptions, onLog?: (msg: string) => void): Promise<Blob> {
  const arrayBuffer = await file.arrayBuffer();
  const zip = await JSZip.loadAsync(arrayBuffer);
  
  const documentXmlPath = 'word/document.xml';
  const documentXml = await zip.file(documentXmlPath)?.async('string');
  
  if (!documentXml) {
    throw new Error('Không tìm thấy nội dung tài liệu Word.');
  }

  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(documentXml, "application/xml");
  const baseStyle = extractBaseStyles(xmlDoc);

  // Handle Header/Footer if settings provided
  if (options.headerFooter) {
    const { headerXml, footerXml } = generateHeaderFooterXmls(options.headerFooter);
    
    // Find all existing header and footer files and overwrite them
    const files = Object.keys(zip.files);
    let headerFound = false;
    let footerFound = false;

    files.forEach(fileName => {
      if (fileName.startsWith('word/header')) {
        zip.file(fileName, headerXml);
        headerFound = true;
      }
      if (fileName.startsWith('word/footer')) {
        zip.file(fileName, footerXml);
        footerFound = true;
      }
    });

    if (!headerFound) zip.file('word/header1.xml', headerXml);
    if (!footerFound) zip.file('word/footer1.xml', footerXml);
  }

  // Handle NLS Integration if options provided
  if (options.nlsOptions) {
    onLog?.(">> Đang trích xuất nội dung văn bản...");
    const textContext = await extractTextFromDocx(file);
    
    onLog?.(">> Đang kết nối AI để thiết kế Năng lực số...");
    const prompt = createIntegrationTextPrompt(textContext, options.nlsOptions.subject, options.nlsOptions.grade);
    const nlsContent = await generateCompetencyIntegration(prompt, options.nlsOptions.apiKey);
    
    onLog?.(">> Đang tích hợp Năng lực số vào file Word...");
    await injectNLSIntoDocx(zip, nlsContent, (msg) => onLog?.(msg));
  }

  const { xml: headerXml, earliestTeachingDate } = generateHeaderXml(options, baseStyle);
  const reflectionXml = options.reflection ? generateReflectionXml(options.reflection, baseStyle, earliestTeachingDate) : '';
  
  // Re-read documentXml because NLS might have changed it
  let currentDocXml = await zip.file(documentXmlPath)?.async('string') || documentXml;
  
  // Find the start and end of the body
  const bodyStartTag = '<w:body>';
  const bodyEndTag = '</w:body>';
  const bodyStartIndex = currentDocXml.indexOf(bodyStartTag);
  const bodyEndIndex = currentDocXml.lastIndexOf(bodyEndTag);
  
  if (bodyStartIndex === -1 || bodyEndIndex === -1) {
    throw new Error('Định dạng file Word không hợp lệ.');
  }

  let bodyContent = currentDocXml.slice(bodyStartIndex + bodyStartTag.length, bodyEndIndex);

  // IMPROVED CLEANUP LOGIC:
  // We want to remove all leading paragraphs and tables that look like the old header.
  // We'll loop through elements at the beginning and remove them if they match header patterns.
  
  const headerPatterns = [
    /Tuần\s*:/i,
    /Tiết\s*PPCT\s*:/i,
    /Ngày\s*soạn\s*:/i,
    /Lớp/i,
    /Ngày\s*dạy/i
  ];

  let cleanBodyContent = bodyContent;
  let changed = true;

  while (changed) {
    changed = false;
    
    // Find the first element (paragraph or table)
    const pStart = cleanBodyContent.indexOf('<w:p');
    const tblStart = cleanBodyContent.indexOf('<w:tbl>');
    
    // Determine which comes first
    let elementStart = -1;
    let elementEnd = -1;

    if (pStart !== -1 && (tblStart === -1 || pStart < tblStart)) {
      elementStart = pStart;
      elementEnd = cleanBodyContent.indexOf('</w:p>', pStart) + 6;
    } else if (tblStart !== -1) {
      elementStart = tblStart;
      elementEnd = cleanBodyContent.indexOf('</w:tbl>', tblStart) + 8;
    }

    // If we found an element near the beginning (within first 100 chars of current start)
    if (elementStart !== -1 && elementStart < 100) {
      const elementContent = cleanBodyContent.slice(elementStart, elementEnd);
      
      // Check if this element contains any header keywords
      // We strip XML tags for better matching
      const plainText = elementContent.replace(/<[^>]+>/g, '');
      
      if (headerPatterns.some(pattern => pattern.test(plainText)) || plainText.trim() === '') {
        // It's a header element or empty, remove it
        cleanBodyContent = cleanBodyContent.slice(elementEnd);
        changed = true;
      }
    }
  }

  // CLEANUP TRAILING REFLECTION LOGIC:
  const reflectionPatterns = [
    /Rút\s*kinh\s*nghiệm/i,
    /Ký\s*duyệt/i,
    /Tổ\s*trưởng/i,
    /Hiệu\s*trưởng/i,
    /Phó\s*hiệu\s*trưởng/i,
    /\.{10,}/ // Dotted lines
  ];

  changed = true;
  while (changed) {
    changed = false;
    
    // Find the last element (paragraph or table)
    const lastPStart = cleanBodyContent.lastIndexOf('<w:p');
    const lastTblStart = cleanBodyContent.lastIndexOf('<w:tbl>');
    
    let elementStart = -1;
    let elementEnd = -1;

    if (lastPStart !== -1 && (lastTblStart === -1 || lastPStart > lastTblStart)) {
      elementStart = lastPStart;
      elementEnd = cleanBodyContent.indexOf('</w:p>', lastPStart) + 6;
    } else if (lastTblStart !== -1) {
      elementStart = lastTblStart;
      elementEnd = cleanBodyContent.indexOf('</w:tbl>', lastTblStart) + 8;
    }

    // If we found an element near the end
    if (elementStart !== -1 && elementEnd >= cleanBodyContent.length - 100) {
      const elementContent = cleanBodyContent.slice(elementStart, elementEnd);
      const plainText = elementContent.replace(/<[^>]+>/g, '');
      
      if (reflectionPatterns.some(pattern => pattern.test(plainText)) || plainText.trim() === '') {
        // It's a reflection element or empty, remove it
        cleanBodyContent = cleanBodyContent.slice(0, elementStart);
        changed = true;
      }
    }
  }

  const newDocumentXml = 
    currentDocXml.slice(0, bodyStartIndex + bodyStartTag.length) + 
    headerXml + 
    cleanBodyContent + 
    reflectionXml +
    currentDocXml.slice(bodyEndIndex);

  zip.file(documentXmlPath, newDocumentXml);
  
  const output = await zip.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });

  return output;
}
